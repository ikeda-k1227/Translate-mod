package jp.kotoba.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class Translator {
    private static final long FAILURE_BACKOFF_MILLIS = Duration.ofSeconds(30).toMillis();
    private static final Pattern TRANSLATED_TEXT = Pattern.compile("\\\"translatedText\\\"\\s*:\\s*\\\"((?:\\\\.|[^\\\"\\\\])*)\\\"");
    private static final String GOOGLE_TRANSLATE_URL = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=ja&dt=t&q=";
    private static final String MYMEMORY_URL = "https://api.mymemory.translated.net/get?mt=1&langpair=en%7Cja&q=";
    private final KotobaConfig config;
    private final HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    private final ConcurrentMap<String, CompletableFuture<String>> inFlight = new ConcurrentHashMap<>();
    private final ConcurrentMap<String, String> cache = new ConcurrentHashMap<>();
    private volatile long unavailableUntilMillis;

    Translator(KotobaConfig config) { this.config = config; }

    String getCached(String text) { return cache.get(text); }

    CompletableFuture<String> translate(String text) {
        String cached = cache.get(text);
        if (cached != null) return CompletableFuture.completedFuture(cached);
        if (System.currentTimeMillis() < unavailableUntilMillis) return CompletableFuture.completedFuture(null);
        return inFlight.computeIfAbsent(text, key -> request(key).whenCompleteAsync((result, error) -> {
            if (result != null && !result.isBlank()) cache.put(key, result);
            else unavailableUntilMillis = System.currentTimeMillis() + FAILURE_BACKOFF_MILLIS;
            inFlight.remove(key);
        }));
    }

    private CompletableFuture<String> request(String text) {
        if (config.provider.equals("google")) {
            // Google's free web endpoint is sometimes blocked or returns a non-JSON
            // anti-bot page. Retry through the keyless MyMemory endpoint in that case.
            return requestGoogle(text).thenCompose(result -> result == null || result.isBlank()
                    ? requestMyMemory(text)
                    : CompletableFuture.completedFuture(result));
        }
        if (config.provider.equals("mymemory")) return requestMyMemory(text);
        return requestLibreTranslate(text);
    }

    private CompletableFuture<String> requestGoogle(String text) {
        try {
            String query = URLEncoder.encode(text, StandardCharsets.UTF_8);
            HttpRequest request = HttpRequest.newBuilder(URI.create(GOOGLE_TRANSLATE_URL + query))
                    .timeout(Duration.ofSeconds(12)).GET().build();
            return client.sendAsync(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8))
                    .thenApply(response -> {
                        if (response.statusCode() < 200 || response.statusCode() >= 300) {
                            System.err.println("[Kotoba Client] Free translation service returned HTTP " + response.statusCode());
                            return null;
                        }
                        try {
                            JsonArray root = JsonParser.parseString(response.body()).getAsJsonArray();
                            JsonArray segments = root.get(0).getAsJsonArray();
                            StringBuilder translated = new StringBuilder();
                            for (JsonElement segment : segments) {
                                if (segment.isJsonArray() && !segment.getAsJsonArray().isEmpty()) {
                                    JsonElement part = segment.getAsJsonArray().get(0);
                                    if (part.isJsonPrimitive() && part.getAsJsonPrimitive().isString()) {
                                        translated.append(part.getAsString());
                                    }
                                }
                            }
                            if (translated.isEmpty()) {
                                System.err.println("[Kotoba Client] Free translation service returned no translated text");
                                return null;
                            }
                            return translated.toString();
                        } catch (RuntimeException error) {
                            System.err.println("[Kotoba Client] Could not parse free translation response");
                            return null;
                        }
                    }).exceptionally(error -> {
                        logRequestFailure(error);
                        return null;
                    });
        } catch (IllegalArgumentException error) {
            logRequestFailure(error);
            return CompletableFuture.completedFuture(null);
        }
    }

    private CompletableFuture<String> requestMyMemory(String text) {
        if (text.getBytes(StandardCharsets.UTF_8).length > 500) {
            System.err.println("[Kotoba Client] MyMemory request exceeded its 500-byte limit");
            return CompletableFuture.completedFuture(null);
        }
        try {
            String query = URLEncoder.encode(text, StandardCharsets.UTF_8);
            HttpRequest request = HttpRequest.newBuilder(URI.create(MYMEMORY_URL + query))
                    .timeout(Duration.ofSeconds(12)).GET().build();
            return client.sendAsync(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8))
                    .thenApply(response -> {
                        if (response.statusCode() < 200 || response.statusCode() >= 300) {
                            System.err.println("[Kotoba Client] MyMemory returned HTTP " + response.statusCode());
                            return null;
                        }
                        try {
                            JsonObject root = JsonParser.parseString(response.body()).getAsJsonObject();
                            if (root.get("responseStatus").getAsInt() != 200) {
                                System.err.println("[Kotoba Client] MyMemory rejected the translation request");
                                return null;
                            }
                            String translated = root.getAsJsonObject("responseData").get("translatedText").getAsString();
                            return translated.isBlank() ? null : translated;
                        } catch (RuntimeException error) {
                            System.err.println("[Kotoba Client] Could not parse MyMemory response");
                            return null;
                        }
                    }).exceptionally(error -> {
                        logRequestFailure(error);
                        return null;
                    });
        } catch (IllegalArgumentException error) {
            logRequestFailure(error);
            return CompletableFuture.completedFuture(null);
        }
    }

    private CompletableFuture<String> requestLibreTranslate(String text) {
        String body = "{\"q\":\"" + jsonEscape(text) + "\",\"source\":\"en\",\"target\":\"ja\",\"format\":\"text\""
                + (config.apiKey.isBlank() ? "" : ",\"api_key\":\"" + jsonEscape(config.apiKey) + "\"") + "}";
        try {
            HttpRequest request = HttpRequest.newBuilder(URI.create(config.endpoint))
                    .timeout(Duration.ofSeconds(12))
                    .header("Content-Type", "application/json; charset=utf-8")
                    .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8)).build();
            return client.sendAsync(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8))
                    .thenApply(response -> {
                        if (response.statusCode() < 200 || response.statusCode() >= 300) {
                            System.err.println("[Kotoba Client] Translation API returned HTTP " + response.statusCode());
                            return null;
                        }
                        Matcher matcher = TRANSLATED_TEXT.matcher(response.body());
                        if (!matcher.find()) {
                            System.err.println("[Kotoba Client] Translation API response did not contain translatedText");
                            return null;
                        }
                        return jsonUnescape(matcher.group(1));
                    }).exceptionally(error -> {
                        logRequestFailure(error);
                        return null;
                    });
        } catch (IllegalArgumentException error) {
            logRequestFailure(error);
            return CompletableFuture.completedFuture(null);
        }
    }

    private void logRequestFailure(Throwable error) {
        unavailableUntilMillis = System.currentTimeMillis() + FAILURE_BACKOFF_MILLIS;
        System.err.println("[Kotoba Client] Translation request failed (" + error.getClass().getSimpleName() + ")");
    }

    private static String jsonEscape(String s) {
        StringBuilder out = new StringBuilder();
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"' -> out.append("\\\""); case '\\' -> out.append("\\\\");
                case '\n' -> out.append("\\n"); case '\r' -> out.append("\\r"); case '\t' -> out.append("\\t");
                default -> { if (c < 0x20) out.append(String.format("\\u%04x", (int)c)); else out.append(c); }
            }
        }
        return out.toString();
    }

    private static String jsonUnescape(String s) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c != '\\' || i + 1 >= s.length()) { out.append(c); continue; }
            char e = s.charAt(++i);
            switch (e) {
                case '"', '\\', '/' -> out.append(e); case 'n' -> out.append('\n'); case 'r' -> out.append('\r'); case 't' -> out.append('\t');
                case 'b' -> out.append('\b'); case 'f' -> out.append('\f');
                case 'u' -> { if (i + 4 < s.length()) { out.append((char)Integer.parseInt(s.substring(i + 1, i + 5), 16)); i += 4; } }
                default -> out.append(e);
            }
        }
        return out.toString();
    }
}

package jp.kotoba.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.ChatType;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

public final class KotobaClient implements ClientModInitializer {
    private static final ThreadLocal<Boolean> internalMessage = ThreadLocal.withInitial(() -> false);
    private static KotobaConfig config;
    private static Translator translator;
    private static KeyMapping toggleDisplayKey;

    @Override
    public void onInitializeClient() {
        config = KotobaConfig.load();
        translator = new Translator(config);
        toggleDisplayKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.kotoba_client.toggle_display", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_F8,
                KeyMapping.Category.MISC));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleDisplayKey.consumeClick()) {
                config.toggleDisplayMode();
                if (client.player != null) {
                    String mode = config.showTranslations ? "翻訳表示" : "原文表示";
                    client.player.sendOverlayMessage(Component.literal("§8[Kotoba] §f表示を" + mode + "に切り替えました"));
                }
            }
        });

        ClientReceiveMessageEvents.ALLOW_CHAT.register((message, signedMessage, sender, params, receptionTimestamp) -> {
            if (internalMessage.get()) return true;
            String content = signedMessage.signedContent();
            if (!shouldTranslate(config.enabled && config.chatEnabled, content)) return true;
            replaceWithTranslation(content, message, false, params);
            return false;
        });
        ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) -> {
            if (internalMessage.get()) return true;
            if (!shouldTranslate(config.enabled && config.gameMessagesEnabled, message)) return true;
            replaceWithTranslation(message.getString(), message, overlay, null);
            return false;
        });
    }

    static Component translatedComponent(Component original, boolean categoryEnabled) {
        if (config == null || translator == null) return original;
        if (!config.enabled || !categoryEnabled || !config.showTranslations) return original;
        String text = original.getString().strip();
        if (!isTranslatable(text)) return original;
        String cached = translator.getCached(text);
        if (cached != null) return Component.literal(cached).withStyle(original.getStyle());
        translator.translate(text);
        return original;
    }

    public static Component translateScoreboard(Component original) {
        if (config == null) return original;
        return translatedComponent(original, config.scoreboardEnabled);
    }

    public static Component translateHologram(Component original) {
        if (config == null) return original;
        return translatedComponent(original, config.hologramsEnabled);
    }

    private static boolean shouldTranslate(boolean categoryEnabled, Component message) {
        return shouldTranslate(categoryEnabled, message.getString());
    }

    private static boolean shouldTranslate(boolean categoryEnabled, String text) {
        return categoryEnabled && config.showTranslations && isTranslatable(text.strip());
    }

    private static boolean isTranslatable(String text) {
        return !text.isEmpty() && text.length() <= config.maxCharacters && !containsJapanese(text);
    }

    private static void replaceWithTranslation(String text, Component original, boolean overlay, ChatType.Bound chatType) {
        String fallback = original.getString();
        translator.translate(text).thenAccept(translated -> {
            Minecraft client = Minecraft.getInstance();
            client.execute(() -> {
                if (client.player == null) return;
                String displayText = translated == null || translated.isBlank() || !config.showTranslations
                        ? fallback : translated;
                Component shown = Component.literal(displayText);
                if (chatType != null) shown = chatType.decorate(shown);
                internalMessage.set(true);
                try {
                    if (overlay) client.player.sendOverlayMessage(shown);
                    else client.player.sendSystemMessage(shown);
                } finally {
                    internalMessage.set(false);
                }
            });
        });
    }

    private static boolean containsJapanese(String text) {
        return text.codePoints().anyMatch(c -> (c >= 0x3040 && c <= 0x30ff) || (c >= 0x3400 && c <= 0x9fff));
    }
}
